//
//  NewsTableViewCell.swift
//  GetDataFromAPI
//
//  Created by apple on 2/25/21.
//

import UIKit

class NewsTableViewCell: UITableViewCell {

    @IBOutlet weak var lblSymbol: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}
