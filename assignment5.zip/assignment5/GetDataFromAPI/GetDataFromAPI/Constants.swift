//
//  Constants.swift
//  GetDataFromAPI
//
//  Created by apple on 2/24/21.
//

import Foundation

let apiKey = "5142bd5d5d384c6bb216fb575d77a737"
let apiURL = "https://newsapi.org/v2/top-headlines?country=us&category=business&apiKey="
