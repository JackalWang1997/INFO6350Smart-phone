//
//  Constants.swift
//  GetDataFromAPI
//
//  Created by apple on 2/24/21.
//

import Foundation

let apiKey = "09a3d94b28b7410db84c6bd3a84b9d6f"
let apiURL = "https://newsapi.org/v2/top-headlines?country=us&category=business&apiKey="

