//
//  TableViewCell.swift
//  TableViewXib
//
//  Created by apple on 2/18/21.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var lblCity: UILabel!
    @IBOutlet weak var lblValue: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
