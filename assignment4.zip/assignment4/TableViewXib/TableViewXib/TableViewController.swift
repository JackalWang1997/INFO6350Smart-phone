//
//  TableViewController.swift
//  TableViewXib
//
//  Created by apple on 2/18/21.
//

import UIKit

class TableViewController: UITableViewController {

    
    let cities = ["Seattle", "Boston", "LA", "New York", "San Deago", "Kirkland", "DC"]
    let temperatures = ["43", "38", "62", "69", "66", "29", "79"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cities.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = Bundle.main.loadNibNamed("TableViewCell", owner: self, options: nil)?.first as! TableViewCell
        
        cell.lblCity.text = cities[indexPath.row]
        cell.lblValue.text = temperatures[indexPath.row] + " F°"
        
        return cell
    }

}
